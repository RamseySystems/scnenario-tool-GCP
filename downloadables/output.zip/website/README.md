##  HOW TO RUN WEBSITE WITH HTTP-SERVER  ##

# Download node
> To download node, go to nodejs.org and download the lastest version. Follow the steps to install

# Download http-server 
> Run - 'npm install http-server'

# Serve the website
> Navigate to your website folder in the terminal
> Run - 'npx http-server' 



At the bottom, it will say something like

Available on:
  http://127.0.0.1:8080
  http://192.168.0.100:8080
Hit CTRL-C to stop the server

Click a link 